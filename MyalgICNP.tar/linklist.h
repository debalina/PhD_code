#ifndef _LINKLIST_H
#define _LINKLIST_H

#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0

struct node {
	int id;
	struct node *next;
};

typedef struct node NODE;

NODE *newNode, *head;

NODE *AppendNode(NODE **headRef, int id);
int CountList(NODE **headRef);
void PrintList(NODE *headRef);
#endif
