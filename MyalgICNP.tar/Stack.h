#ifndef _STACK_H
#define _STACK_H

#include <stdio.h>
#include <stdlib.h>

typedef struct stack {
	int data;
	struct stack *next;
} STACK;


int pathLength;

#endif
