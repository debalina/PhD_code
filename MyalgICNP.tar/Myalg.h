#ifndef _MYALG_H
#define _MYALG_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "input.h"
#include "linklist.h"
#include "Stack.h"

typedef struct  {
	int numInterferers;
	int fId;
} BS;

NODE **BSList;

NODE **NeighborList;

STACK **st;

int **prefTiles;

void readPrefSubbands(FILE *file,  int numFemtocells, int numTiles);

BS *node;
#endif
