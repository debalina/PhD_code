#include "Stack.h"

int notEmpty(STACK **head)
{
	if (*head==NULL)
		return 0;
	else
		return 1;
}

int push(STACK **head, int value)
{
	STACK *node = malloc(sizeof(STACK));

	if (node==NULL)
	{
		fputs("Error: no space available for node\n", stderr);
		abort();
	} else
	{
		node->data = value;
		if (*head==NULL)
		{
			pathLength = 0;
			node->next = NULL;
		} else {
			node->next = *head;
			pathLength++;
		}	
		*head = node;
	}
	return pathLength;
}

int pop(STACK **head)
{
	if (*head==NULL)
	{
		pathLength = 0;
		fputs("Error: stack undeflow\n", stderr);
		abort();
	} else {
		STACK *top = *head;
		int value = top->data;
		*head = top->next;
		free(top);
		pathLength--;
		return value;
	}
}
