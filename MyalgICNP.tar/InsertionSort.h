#ifndef _INSERT_SORT_H
#define _INSERT_SORT_H

#include <stdio.h>

#include "Myalg.h"

void insertSort(BS *A, int n);

#endif
