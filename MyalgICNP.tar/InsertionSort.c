#include "InsertionSort.h"


void insertSort(BS *A, int N)
{
	int i, j;
	int keyInterferers, keyfId;
	for (j=1; j< N; j++)
	{
		keyInterferers = A[j].numInterferers;
		keyfId = A[j].fId;
		i = j-1;
		while ((i>=0) && (A[i].numInterferers<keyInterferers))
		{
			A[i+1].numInterferers=A[i].numInterferers;
			A[i+1].fId =A[i].fId;
			i=i-1;
		}
		A[i+1].numInterferers = keyInterferers;
		A[i+1].fId = keyfId;
	}
}

