#include "Myalg.h"


int main(int argc, char* argv[])
{
	FILE *infile, *preffile, *outfile;
	int f, f1, ifr, i;
	int IntFlag, DoneFlag, Flag;
	int pointer;
	int pTile;
	int   *consideredTiles, **allocTiles;
	int *pTr;
	int t;
	int bs;
	int next;
	float *tilesAlloced, *tilesUsed;
	float SSR, thSatRate, totalTiles;
	float *TSR;
	float TotalThruPut, AvgThruPut;
	struct timeval start, end;
	int TotalTilesReqd;
	float totalNodes[4];
	int w;
	float **tiles;

	gettimeofday(&start, NULL);
	/* Here we have two input files. One is the same as all the other algos
	 * It contains the number of femtocells, number of tiles and the ids of
	 * interferers of each femtocell. The other input file contains the list
	 * of tiles in a preferred order for each femtocell.
	 */

	if (argc < 4)
	{
		fprintf(stderr, "usage: %s input filename preferred input filename output filename\n",argv[0]);
		exit(1);
	}

	infile = fopen(argv[1],"r");
	if (infile == NULL)
	{
		fprintf(stderr, "File %s could not be opened for reading \n", argv[1]);
		exit(1);
	}

	preffile = fopen(argv[2],"r");
	if (preffile == NULL)
	{
		fprintf(stderr, "File %s could not be opened for reading \n", argv[2]);
		exit(1);
	}
	outfile = fopen(argv[3],"w");

	srand(time(NULL));

	/* read input */
	readInput(infile);
	readPrefSubbands(preffile,  numFemtocells, numTiles);


	node = malloc(numFemtocells *sizeof(BS));
	tilesAlloced = malloc(numFemtocells *sizeof(float));
	tilesUsed = malloc(numTiles *sizeof(int));
	TSR = malloc(numFemtocells*sizeof(float));
	tiles = (float**)malloc(numFemtocells *sizeof(float*));
	for (i=0; i<numFemtocells; i++)
	{
		tiles[i] = malloc(numFrames*sizeof(float));
	}

	for (f=0; f< numFemtocells; f++)
	{
		node[f].fId = f;
		node[f].numInterferers = numInterferers[f];
	}


	for (f=0; f< numFemtocells; f++)
	{
		tilesAlloced[f] = 0;
		TSR[f] = 0;
	}

	for (t=0; t<numTiles; t++)
	{
		tilesUsed[t]=0;
	}

	insertSort(node, numFemtocells);	

	for (f=0; f<numFemtocells; f++)
	{
		//fprintf(outfile,"BS %d %d\n",node[f].fId,node[f].numInterferers);
	}


	pTr = malloc(numFemtocells * sizeof(int));
	allocTiles = malloc(numFemtocells * sizeof(int*));
	consideredTiles = malloc(numTiles * sizeof(int));

	for (f=0; f<numFemtocells; f++)
	{
		allocTiles[f] = malloc(numTiles *sizeof(int));
	}

	for (f=0; f<numFemtocells; f++)
	{
		for (t=0; t<numTiles; t++)
		{
			allocTiles[f][t]=-1;
			pTr[f] = 0;
			consideredTiles[t]=0;
		}
	}


	/* Make a linked list with nodes and their neighbors */

	NeighborList = malloc (numFemtocells * sizeof(NODE *));
	for (f=0; f< numFemtocells; f++)
	{
		NeighborList[f] = NULL;
	}

	for (f = 0; f < numFemtocells; f++)
	{
		for (f1 = 0; f1 < numFemtocells; f1++)
		{
			
			if (Interferers[f][f1]==1)
			{
				/*Add f1 to linked list of f*/
				AppendNode(&NeighborList[f], f1);
			}
		}
	}
	
	for (f=0; f< numFemtocells; f++)
	{
		printf("\n Node %d Neighbors", f); 
		PrintList(NeighborList[f]);
	}

	/*for (f=0; f< numFemtocells; f++)
	{
		CalcPathLength(NeighborList, f);
	}*/

	pathLength = DFS(NeighborList);

	fprintf(outfile, "pathlength is %d \n", pathLength);
	//maxPathLength = findMax(pathLength, numFemtocells);

	BSList = malloc(numTiles * sizeof(NODE*));
	
	{
		BSList[t] = NULL;
	}
	
	/* subband allocation algorithm */
	for (t=0; t<numTiles; t++)
	{
		for (f=0; f<numFemtocells; f++)
		{
			/* pTiles is the t-th tile in the preferred list*/
			pTile = prefTiles[f][t];
			printf("Considering tile %d for femtocell %d \n", pTile, f);
			/* Check if pTiles has already been allocated
			 * to any interfering node. If not, assign it to
			 * f */
			IntFlag = FALSE;
			for (f1 = 0; ((f1 <numFemtocells) &&( f1!=f)); f1++)
			{

				if (Interferers[f][f1]==1)
				{
					IntFlag = searchList(&BSList[pTile], f1);
					if (IntFlag == TRUE)
					{
						printf("Interference between %d and %d\n",f,f1);
						allocTiles[f][pTile] = 0;
						break;
						
					}
					//fprintf(outfile,"Looking for Interfererence between %d and %d %d\n", f1,f, IntFlag);
				}
			}


			if (IntFlag == FALSE)
			{
				/*assign this tile to the femtocell f1*/
				allocTiles[f][pTile]=1;
				AppendNode(&BSList[pTile], f);
			}	else
			{
				allocTiles[f][pTile] = 0;
			}


		}	

	}
	
	for (f=0; f<numFemtocells; f++)
	{
		for (t=0; t<numTiles; t++)
		{
			if (allocTiles[f][t]==-1)
			{
				printf("Tile %d not considered for femtocell %d\n",t,f);
			}
		}
	}

		fprintf(outfile,"\n numFemtocells %d Max Interferers %d \n", numFemtocells, maxI);
		/* Print Tile Allocation*/
		for (f=0; f<numFemtocells; f++)
		{
			fprintf(outfile,"\n\n Node %d Alloced Tiles ",f);
			for (t=0; t<numTiles; t++)
			{
				if (allocTiles[f][t]==1)
				{
					tilesAlloced[f]++;
					tilesUsed[t]++;
					fprintf(outfile,"%d ",t);
				}
			}
		}
		for (w=0; w<4; w++)
			totalNodes[w] = 0;
	
		TotalThruPut = 0;	
		for (i=0; i<numFrames; i++)
		{
			TotalTilesReqd = 0;
			for (f=0; f<numFemtocells; f++)
			{
				tiles[f][i] = tilesAlloced[f];
			}
			for (f=0; f<numFemtocells; f++)
			{
				fprintf(outfile, "Initial tile alllocation node %d tiles %f\n", f, tiles[f][i]);
				 while  (tilesReqd[f][i] > tiles[f][i])
				{
					/* Check if neighbor has unused tiles.
					 * Borrow neighbors tiles
					 */

					for (t=0; t<numTiles; t++)
					{
						if (allocTiles[f][t]==0)
						{
							Flag = 1;
							for (f1 = 0; ((f1 <numFemtocells) &&( f1!=f)); f1++)
							{

								if (Interferers[f][f1]==1)
								{
									if (tilesReqd[f1][i] > tiles[f1][i])
									{
										Flag = 0;
									}
								}
								
							}
						}
						if ((allocTiles[f][t]==0) && (Flag == 1))
						{
							tiles[f][i] +=1;
							for (f1 = 0; ((f1 <numFemtocells) &&( f1!=f)); f1++)
							{

								if ((Interferers[f][f1]==1) && (tilesReqd[f1][i] < tiles[f1][i]) && (allocTiles[f1][t]==1))
								{
									tiles[f1][i]-=1;
								}
							}
						}
					}
				}
				fprintf(outfile, "after borrowing  tile alllocation node %d tiles %f\n", f, tiles[f][i]);
			}

			for (f=0; f<numFemtocells; f++)
			{
				if (tilesReqd[f][i] > 0)
					TSR[f] = tiles[f][i]/tilesReqd[f][i];
				else TSR[f] = 1;

				if (TSR[f] > 1.0)
					TSR[f] = 1.0;
				TotalTilesReqd += tilesReqd[f][i];
				fprintf(outfile," frame %d node %d tilesReqd %d TSR %lf \n",i,f,tilesReqd[f][i],TSR[f]);
				thSatRate = thSatRate + TSR[f];
				TotalThruPut+= tiles[f][i];
			}

			thSatRate = thSatRate/numFemtocells;
			totalTiles = 0;
			for (f=0; f<numFemtocells; f++)
			{
				totalTiles = totalTiles + tilesAlloced[f];
			}
			SSR = totalTiles/(numTiles*numFemtocells);

			fprintf(outfile,"\n \n frame %d TotalTilesReqd %d TSR %lf SSR %lf TotalThruPut %f \n",i,TotalTilesReqd,thSatRate, SSR, TotalThruPut);
			for (f=0; f<numFemtocells; f++)
			{
				if (TSR[f] == 0)
				{
					totalNodes[0]++;
				}
				if (TSR[f] <=0.25)
				{
					totalNodes[1]++;
				}	
				if (TSR[f] <=0.5)
				{
					totalNodes[2]++;
				}
				if (TSR[f] <=0.75)
				{
					totalNodes[3]++;
				}
			}


		}
		AvgThruPut = TotalThruPut/numFrames;
		fprintf(outfile,"\n Average ThruPut %f \n", AvgThruPut);
		for (w=0; w<4; w++)
			fprintf(outfile,"%f ",(totalNodes[w]/(numFrames *numFemtocells)));
		gettimeofday(&end, NULL);
		fprintf(outfile,"Time = %ld micros \n",((end.tv_sec*1000000+end.tv_usec) - (start.tv_sec*1000000 + start.tv_usec)));
}


void readPrefSubbands(FILE *file,  int numFemtocells, int numTiles)
{
	int i, f, fId;
	char *token;
	const char delims[]=" ";
	char linebuffer[2000];
	int tile;

	prefTiles = malloc(numFemtocells *sizeof(int*));
	for (f=0; f<numFemtocells; f++)
	{
		prefTiles[f] = malloc(numTiles *sizeof(int));
	}

	while (!feof(file))
	{
		fgets(linebuffer, 2000, file);
		token = strtok(linebuffer,delims);
		fId = atoi(token);

		token=strtok(NULL,delims);
		i = 0;
		while (token!=NULL)
		{
			tile = atoi(token);
			prefTiles[fId][i] = tile;
			i++;
			token=strtok(NULL,delims);
		}
	}

}

/*
int CalcPathLength(NODE **N, int start)
{
	NODE *p;
	int *visited;
	int f;
	int parent;
	int pathLength;
	int AllVisited;

	visited = malloc(numFemtocells * sizeof(int));
	
	for (f=0; f<numFemtocells; f++)
	{
		visited[f] = 0;
		if (N[f] == NULL)
		{
			visited[f] = 1;
		}
	}

	pathLength = push(&st, start);
	p = N[start];
	
	if (p!=NULL)	
		AllVisited = 0;
	else
		AllVisited = 1;

	while (AllVisited==0)
	{

		while (p!=NULL)
		{
			push(st, p->id);
			visited[p->id] = 1;
			printf("Calc Path Length node %d pathlength %d",p->id, pathLength);
			 p= N[p->id];
		}

		if (p==NULL)
		{
			parent = pop(st);
			if (parent!=-1)
			{
				p = N[parent];
				if (visited[p->id]==1)
					p = p->next;
			}

		}
		
		AllVisited = 1;
		for (f=0; f<numFemtocells; f++)
		{
			if (visited[f]==0)
			{
				AllVisited = 0;
				break;
			}
		}
	}
	

	free(visited);
}
*/

int DFS(NODE **N)
{
	int visited[numFemtocells], index[numFemtocells];
	int counter;
	int root[numFemtocells];
	NODE *p;
	int maxPl = 0;
	int u, v, w;

	for (u=0; u< numFemtocells; u++)
		visited[u] = 0;

	for (u=0; u<numFemtocells; u++)
		if (!visited[u])
		{
			counter = 0;
			push(&st, u);
	
			while (notEmpty(st))
			{
				v = pop(&st);
				if (!visited[v])
				{
					visited[v] = 1;
					root[v] = u;
					index[v] = counter;
					counter++;
					//printf("v is %d \n", v);

					/*for (each neighbor w of v)*/
					p = N[v];
					while (p!=NULL)
					{
						w = p->id;
						if (!visited[w])
							push(&st,w);
						p = p->next;
					}
					if (p==NULL)
					{
					       if (maxPl < counter)
					       {
						       maxPl = counter-1;
						       printf("maxPl is %d \n",maxPl);
					       }
					}
				}
			}

		}
		return maxPl;
}
