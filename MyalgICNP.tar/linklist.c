#include "linklist.h"


void PrintList(NODE *headRef)
{
        NODE *curr = headRef;

        while (curr!=NULL)
        {
                printf( "\t%d ",curr->id);
                curr = curr->next;
        }
}

int CountList(NODE **headRef)
{
        NODE *current = *headRef;
        int count = 0;

        while (current!=NULL)
        {
                count++;
                current = current->next;
        }
        return count;
}

int searchList(NODE **headRef, int id)
{
        NODE *current = *headRef;
        int flag = FALSE;

        while (current!=NULL)
        {
                if (current->id==id)
                {
                       return TRUE;
                }
                current = current->next;
        }
        return FALSE;
}

int getBS(NODE *headRef, int ptr)
{
	NODE *current ;
	int i;
	int id;

	id = -1;

	current = headRef;

	for (i=0; i<=ptr; i++)
	{
		
		while (current!=NULL)
			current = current->next;
	}
	if (current!=NULL)
		id = current->id;

	return id;
}


NODE *AppendNode(NODE **headRef, int id)
{
        NODE *current = *headRef;
        NODE *newNode;

        newNode = malloc(sizeof(NODE));
        newNode->id = id;
        newNode->next = NULL;

        if (current == NULL)
        {
              *headRef = newNode;
        }
        else {
                while (current->next!=NULL)
                {
	                if ((current->id == id) )
                        {
				return;
																										                        }
                        current = current->next;
                }
                if (current->id == id) 
                {
                       return;
                }
                current->next = newNode;
													        }
}

