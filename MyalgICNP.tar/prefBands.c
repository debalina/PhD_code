#include "prefBands.h"

int main(int argc, char *argv[])
{
	FILE  *preffile;
	char *token;
	int numFemtocells;
	int numTiles;
	int f, i;
	int tile;
	int *Allocated;

	if (argc < 4)
	{
		fprintf(stderr, "usage: %s number of Femtocells number of Tiles output filename\n",argv[0]);
		exit(1);
	}

	token = argv[1];
	numFemtocells = atoi(token);
	token = argv[2];
	numTiles = atoi(token);
	printf("number of Femtocells is %d number of Tiles is %d\n", numFemtocells, numTiles);

	preffile = fopen(argv[3],"w");
	srand(time(NULL));

	Allocated = (malloc)(numTiles*sizeof(int));


	for (f=0; f<numFemtocells; f++)
	{
		for (i=0; i<numTiles; i++)
		{
			Allocated[i] = FALSE;
		}
		fprintf(preffile,"%d ",f);
		for (i=0; i<numTiles; i++)
		{
			tile = rand() % numTiles;
			while ((i<numTiles) && (Allocated[tile]==TRUE))
			{
				tile += 1;
			       if (tile == numTiles)
			       {
					tile = 0;
			 	}		
			}
			Allocated[tile]=TRUE;
			fprintf(preffile,"%d ",tile);
		}
		fprintf(preffile,"\n");
	}
	free(Allocated);
	
}
