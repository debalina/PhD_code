#ifndef _PREFBANDS_H
#define _PREFBANDS_H


#include <stdio.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE 1

int **prefBands;
#endif
