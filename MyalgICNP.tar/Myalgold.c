#include "Myalg.h"


int main(int argc, char* argv[])
{
	FILE *infile, *preffile, *outfile;
	int f, f1, ifr, i;
	int IntFlag, DoneFlag;
	int pointer;
	int pTile;
	int   *consideredTiles, **allocTiles;
	int *pTr;
	int t;
	int bs;
	int next;
	float *tilesAlloced, *tilesUsed;
	float SSR, thSatRate, totalTiles;
	float *TSR;
	struct timeval start, end;
	int TotalTilesReqd;
	float totalNodes[4];
	int w;

	gettimeofday(&start, NULL);
	/* Here we have two input files. One is the same as all the other algos
	 * It contains the number of femtocells, number of tiles and the ids of
	 * interferers of each femtocell. The other input file contains the list
	 * of tiles in a preferred order for each femtocell.
	 */

	if (argc < 4)
	{
		fprintf(stderr, "usage: %s input filename preferred input filename output filename\n",argv[0]);
		exit(1);
	}

	infile = fopen(argv[1],"r");
	if (infile == NULL)
	{
		fprintf(stderr, "File %s could not be opened for reading \n", argv[1]);
		exit(1);
	}

	preffile = fopen(argv[2],"r");
	if (preffile == NULL)
	{
		fprintf(stderr, "File %s could not be opened for reading \n", argv[2]);
		exit(1);
	}
	outfile = fopen(argv[3],"w");

	srand(time(NULL));

	/* read input */
	readInput(infile);
	readPrefSubbands(preffile,  numFemtocells, numTiles);


	node = malloc(numFemtocells *sizeof(BS));
	tilesAlloced = malloc(numFemtocells *sizeof(float));
	tilesUsed = malloc(numTiles *sizeof(int));
	TSR = malloc(numFemtocells*sizeof(float));

	for (f=0; f< numFemtocells; f++)
	{
		node[f].fId = f;
		node[f].numInterferers = numInterferers[f];
	}


	for (f=0; f< numFemtocells; f++)
	{
		tilesAlloced[f] = 0;
		TSR[f] = 0;
	}

	for (t=0; t<numTiles; t++)
	{
		tilesUsed[t]=0;
	}

	insertSort(node, numFemtocells);	

	for (f=0; f<numFemtocells; f++)
	{
		//fprintf(outfile,"BS %d %d\n",node[f].fId,node[f].numInterferers);
	}


	pTr = malloc(numFemtocells * sizeof(int));
	allocTiles = malloc(numFemtocells * sizeof(int*));
	consideredTiles = malloc(numTiles * sizeof(int));

	for (f=0; f<numFemtocells; f++)
	{
		allocTiles[f] = malloc(numTiles *sizeof(int));
	}

	for (f=0; f<numFemtocells; f++)
	{
		for (t=0; t<numTiles; t++)
		{
			allocTiles[f][t]=0;
			pTr[f] = 0;
			consideredTiles[t]=0;
		}
	}

	BSList = malloc(numTiles * sizeof(NODE*));
	for (t=0; t<numTiles; t++)
	{
		BSList[t] = NULL;
	}
	DoneFlag = FALSE;
	
	/* subband allocation algorithm */

	while (DoneFlag == FALSE)
	{
		for (f=0; f<numFemtocells; f++)
		{
			pointer = pTr[f];
			pTile = prefTiles[f][pointer];
			while (consideredTiles[pTile] ==1)
			{
				pointer++;
				if (pointer == numTiles)
				{
					break;
				}
				pTile = prefTiles[f][pointer];
			}

			if (pointer == numTiles)
			{
				continue;
			}
			consideredTiles[pTile]=1;

			/*while (allocTiles[f][pTile] ==1)
			{
				pointer++;
				if (pointer == numTiles)
				{
					break;
				}
			}
			if (pointer == numTiles)
			{
				continue;
			}
			*/
			/* unallocated Tile */
			allocTiles[f][pTile]=1;
			pTr[f]= pointer+1;
			AppendNode(&BSList[pTile], f);
			//fprintf(outfile,"\n Tile %d ",pTile);
			PrintList(BSList[pTile], outfile);	
			for (f1 = 0; ((f1 <numFemtocells) &&( f1!=f)); f1++)
			{
				IntFlag = FALSE;
				ifr = 0;

				while ((IntFlag==FALSE) && (ifr < numFemtocells))
				{
					if (Interferers[f1][ifr]==1)
					{
						IntFlag = searchList(&BSList[pTile], ifr);
						//fprintf(outfile,"Looking for Interfererence between %d and %d %d\n", f1,ifr, IntFlag);
					}
					ifr ++;
				}	


				if (IntFlag == FALSE)
				{
					/*assign this tile to the femtocell f1*/
					allocTiles[f1][pTile]=1;
					AppendNode(&BSList[pTile], f1);
					//fprintf(outfile,"\n Tile %d ",pTile);
				//	PrintList(BSList[pTile], outfile);
				}	
			}

		}
		DoneFlag = TRUE;

			for (t=0; t< numTiles; t++)
			{
				if (consideredTiles[t]==0)
				{
					DoneFlag = FALSE;
				}
			}
		}

		fprintf(outfile,"\n numFemtocells %d Max Interferers %d \n", numFemtocells, maxI);
		/* Print Tile Allocation*/
		for (f=0; f<numFemtocells; f++)
		{
			fprintf(outfile,"\n\n Node %d ",f);
			for (t=0; t<numTiles; t++)
			{
				if (allocTiles[f][t]==1)
				{
					tilesAlloced[f]++;
					tilesUsed[t]++;
					fprintf(outfile,"%d ",t);
				}
			}
		}
		for (w=0; w<4; w++)
			totalNodes[w] = 0;
		
		for (i=0; i<numFrames; i++)
		{
			TotalTilesReqd = 0;
			for (f=0; f<numFemtocells; f++)
			{
				if (tilesReqd[f][i] > 0)
					TSR[f] = tilesAlloced[f]/tilesReqd[f][i];
				else TSR[f] = 1;
				TotalTilesReqd += tilesReqd[f][i];
				fprintf(outfile," frame %d node %d TSR %lf \n",i,f,TSR[f]);
				thSatRate = thSatRate + TSR[f];
			}

			thSatRate = thSatRate/numFemtocells;
			totalTiles = 0;
			for (f=0; f<numFemtocells; f++)
			{
				totalTiles = totalTiles + tilesAlloced[f];
			}
			SSR = totalTiles/(numTiles*numFemtocells);

			fprintf(outfile,"\n \n frame %d TotalTilesReqd %d TSR %lf SSR %lf \n",i,TotalTilesReqd,thSatRate, SSR);
			for (f=0; f<numFemtocells; f++)
			{
				if (TSR[f] == 0)
				{
					totalNodes[0]++;
				}
				if (TSR[f] <=0.25)
				{
					totalNodes[1]++;
				}	
				if (TSR[f] <=0.5)
				{
					totalNodes[2]++;
				}
				if (TSR[f] <=0.75)
				{
					totalNodes[3]++;
				}
			}


		}
		fprintf(outfile,"\n CDF ");
		for (w=0; w<4; w++)
			fprintf(outfile,"%f ",(totalNodes[w]/(numFrames *numFemtocells)));
		gettimeofday(&end, NULL);
		fprintf(outfile,"Time = %ld micros \n",((end.tv_sec*1000000+end.tv_usec) - (start.tv_sec*1000000 + start.tv_usec)));
}


void readPrefSubbands(FILE *file,  int numFemtocells, int numTiles)
{
	int i, f, fId;
	char *token;
	const char delims[]=" ";
	char linebuffer[2000];
	int tile;

	prefTiles = malloc(numFemtocells *sizeof(int*));
	for (f=0; f<numFemtocells; f++)
	{
		prefTiles[f] = malloc(numTiles *sizeof(int));
	}

	while (!feof(file))
	{
		fgets(linebuffer, 2000, file);
		token = strtok(linebuffer,delims);
		fId = atoi(token);

		token=strtok(NULL,delims);
		i = 0;
		while (token!=NULL)
		{
			tile = atoi(token);
			prefTiles[fId][i] = tile;
			i++;
			token=strtok(NULL,delims);
		}
	}

}


		
