#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int hash(int prime, int num, int numFemtocells)
{
	int u, len;
	char *str, *p; 
	char *strCopy, *pEnd;
	int i,j,k;
	char strNum[100];
	int blockSize, numBlocks;
	char pad[100], *block;
	int a, sum;
	long int blockNum, hashValue;
	float l;

	/* Convert number to binary*/
	str = malloc(sizeof(long)*8*sizeof(char));
	p = str;
	u = num;
	len = 0;
	while (u > 0)
	{
		(u & 0x1) ? (*p++='1'): (*p++='0');

		u>>=1;
		len++;
	}
	//while (p--!=str)
	//	printf("%c",*p);
	
	/* find out what is the size of each block */
	blockSize = floor (log(prime)/log(2));
	l = log(numFemtocells)/log(2);	
//	printf("blockSize is %d\n", blockSize);
	numBlocks = floor(l/blockSize);
//	printf("numBlocks is %d\n",numBlocks);	

	/*pad str with 0s in front */
	for (j=0; j<len; j++)
	{
		pad[j] = str[j];
	}
	pad[j]='\0';
//	printf("padded string is %s\n", pad);	
	for (i=j; i<(j+blockSize*numBlocks-len); i++)
	{
		pad[i]='0';
	}
	pad[i]='\0';
//	printf("padded string is %s\n", pad);	
//
	       
	sum = 0;
	//srand(time(NULL));
	j=0;
	block=malloc(sizeof(char)*(blockSize+1));
	for (k=0; k< numBlocks; k++)
	{
		/* generate vector a less than prime */
		a = rand()%prime;
//		printf("random number is %d\n",a);

		/* get the binary block */
		for (i=blockSize-1; i>=0; i--)
		{
		//	printf(" i %d\n",i);
			block[i] = pad[j];
			j++;
		}
		block[blockSize] = '\0';
//		printf("block is %s ",block);
		/*convert block to int */
		blockNum = strtol(block, &pEnd,2);
//		printf("blockNum is %ld\n",blockNum);
		sum = sum + blockNum * a;
//		printf("sum is %d\n",sum);
	}

	/*Compute hash*/
	hashValue = sum % prime;

//	printf("hash is %ld\n", hashValue);


	free(str);

	return hashValue;
}
