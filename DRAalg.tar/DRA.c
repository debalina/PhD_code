/* ***********************************************************************/
/*	DRA - Sundaresan Mobihoc 09 	*/
/****************************************/

#include "DRA.h"

/* read all the info like number of tiles reqd by a node, interference patterns */
int main(int argc, char* argv[])
{
	int prime;
	int hashValue;
	int entry;
	int i,f,k;
	int numIter;
	int Alloc[500][500], Collid[500][500];
	FILE *infile, *outfile;
	int frame = 0;
	int collFlag = TRUE;
	float *tilesAlloced;
        int	*tilesUsed;
	float SSR, thSatRate, totalTiles;
	float TotalThruPut, AvgThruPut;
	float *TSR;
	struct timeval start, end;
	int TotalTilesReqd = 0;
	float totalNodes[4];
	int w;

	gettimeofday(&start, NULL);
	if (argc < 3)
	{
		fprintf(stderr, "usage: %s input filename output filename\n",argv[0]);
		exit(1);
	}

	infile = fopen(argv[1],"r");
	if (infile == NULL)
	{
		fprintf(stderr, "File %s could not be opened for reading \n", argv[1]);
		exit(1);
	}

	outfile = fopen(argv[2],"w");

	srand(time(NULL));
	readInput(infile);

	tilesAlloced = malloc(numFemtocells *sizeof(float));
	tilesUsed = malloc(numTiles *sizeof(int));
	TSR = malloc(numFemtocells*sizeof(float));
	
	for (f=0; f< numFemtocells; f++)
	{
		tilesAlloced[f] = 0;
		TSR[f] = 0;
	}

	for (k=0; k<numTiles; k++)
	{
		tilesUsed[k]=0;
	}

	while (collFlag==TRUE)	
	{
		if (frame==0)
		{
			for (f=0; f<numFemtocells; f++)
			{
				for (k=0; k<numTiles; k++)
				{ 
					Alloc[f][k] = 0;
				}
				fprintf(outfile,"\n \n Femtocell id %d\n", f);
				prime = findClose(numInterferers[f]);
				printf("femtocell %d number of Interferers %d Closest prime is %d\n", f,numInterferers[f],prime);
				/* do the hash function */
				numIter = ceil(numTiles/prime);
				//printf("numIter is %d\n",numIter);
				for (i=0; i <numIter; i++)
				{
					hashValue=hash(prime,f, numFemtocells);
					printf("hash is %d\n", hashValue);
					entry = i*prime + hashValue;
					fprintf( outfile,"entry is %d %d \n", i, entry);
					Alloc[f][entry] = 1;	
				}
			}

		}
		else
		{
			/* Frame >= 1*/
			for (f=0; f<numFemtocells; f++)
			{
				for (k=0; k<numTiles; k++)
				{ 
					Collid[f][k] = 0;
				}

				for (k=0; k<numTiles; k++)
				{
					/*Check if this tile is occupied by f and an interferer */
					if (Alloc[f][k] ==1)
					{
						for (i=0; i< numFemtocells; i++)
						{
							if ((Interferers[f][i]==1)  && (Alloc[i][k]==1))
							{
								Collid[f][k] = 1;
								fprintf( outfile,"Cells %d and %d collide in tile %d\n",f,i,k);
							}
						}
					}
				
				}
				collFlag = FALSE;
				for (k=0; k<numTiles; k++)
				{
					if (Collid[f][k]==1)
					{
						collFlag = TRUE;
						hashValue = hash(2,f,numFemtocells);
						Alloc[f][k] = hashValue;
					}
				}
			}
		}
	
		/* PRINT THE RESULTS */
		fprintf(outfile, "\n numFemtocells %d maxInterferers %d\n", numFemtocells, maxI);

		for (f=0; f<numFemtocells; f++)
		{
			fprintf(outfile, "\n\n round %d Femtocell %d \n", frame,f);
			for (k=0; k< numTiles; k++)
			{
				if (Alloc[f][k]==1)
				{
					fprintf(outfile,"%d ",k);
				}
			}
			fprintf(outfile,"\n");
		}
		frame++;

	
	}
	
	for (f=0; f<numFemtocells; f++)
	{
		for (k=0; k< numTiles; k++)
		{
			if (Alloc[f][k]==1)
			{
				tilesAlloced[f]++;
				tilesUsed[k]++;
			}
		}
	}

 	TotalThruPut=0;	
	for (w=0; w<4; w++)
		totalNodes[w] = 0;
	for (i=0; i<numFrames; i++)
	{
		TotalTilesReqd = 0;
		for (f=0; f<numFemtocells; f++)
		{
			if (tilesReqd[f][i]>0)
			{
				TSR[f] = tilesAlloced[f]/tilesReqd[f][i];
			}
			else TSR[f] = 1;
			TotalThruPut+= tilesAlloced[f];
			fprintf(outfile,"\n \n frame %d node %d TSR %lf \n",i,f, TSR[f]);
			
			thSatRate = thSatRate + TSR[f];
			TotalTilesReqd += tilesReqd[f][i];
		}
		//fprintf(outfile,"\n thSatRate %f numFemtocells %d",thSatRate,numFemtocells);
		//fprintf(outfile,"\n thSatRate %f numFemtocells %d",thSatRate,numFemtocells);
		thSatRate = thSatRate/numFemtocells;
		totalTiles = 0;
		for (f=0; f<numFemtocells; f++)
		{

			totalTiles = totalTiles + tilesAlloced[f];
		}
		SSR = totalTiles/(numTiles*numFemtocells);
		fprintf(outfile,"\n \n frame %d TotalTilesReqd %d TSR %f SSR %f \n",i, TotalTilesReqd, thSatRate, SSR);
		for (f=0; f<numFemtocells; f++)
		{
			if (TSR[f] == 0)
			{
				totalNodes[0]++;
			}
			if (TSR[f] <=0.25)
			{
				totalNodes[1]++;
			}	
			if (TSR[f] <=0.5)
			{
				totalNodes[2]++;
			}
			if (TSR[f] <=0.75)
			{
				totalNodes[3]++;
			}
		}

	}

	AvgThruPut = TotalThruPut/numFrames;
	fprintf(outfile,"\nCDF Average Thruput %f",AvgThruPut);
	for (w=0; w<4; w++)
		fprintf(outfile,"%f ",(totalNodes[w]/(numFemtocells*numFrames)));
	gettimeofday(&end,NULL);

	fprintf(outfile, "Time = %ld micros\n", ((end.tv_sec *1000000 + end.tv_usec) - (start.tv_sec*1000000 + start.tv_usec)));	
	fclose(outfile);
	return 0;
}


/* find the closest prime to the number of Interferes. First, we find the difference between the Interferers and the prime and choose the prime which has the least absolute difference */

int findClose(int Interferers)
{
	int i, min, p;
	int numPrimes = 24;
	int diff[30];
	int primes[25] = {3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97};

	/* find the difference between the number of Interferers and prime */
	for (i=0; i<numPrimes;i++)
	{
		diff[i] = abs (Interferers - primes[i]);
	}

	min = diff[0];
	p = primes[0];
	for (i=1; i< numPrimes; i++)
	{
		if (diff[i] < min)
		{
			min = diff[i];
			p= primes[i];
		}
	}
	return p;
}

