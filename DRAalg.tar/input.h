#ifndef _INPUT_H
#define _INPUT_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DEBUG 1

int numFemtocells;
int numTiles;
int numFrames;
int maxI;
int *numInterferers;
int **Interferers;
int **tilesReqd;

void readInput(FILE *fp);
void printInput();
#endif
