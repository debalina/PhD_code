#ifndef _DRA_H
#define _DRA_H


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include "input.h"

#define FALSE 0
#define TRUE 1

int findClose(int num);
#endif
