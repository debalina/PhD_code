#include "input.h"


void readInput(FILE *file)
{
	int i, j,f,ifr;
	const char delims[]=" \n";
	char *token;
	char linebuffer[5000];
	int req;

	fgets(linebuffer, 5000, file);
	
	token = strtok(linebuffer, delims);
	numFemtocells = atoi(token);
	token = strtok(NULL,delims);
	numTiles = atoi(token);
	token = strtok(NULL,delims);
	numFrames = atoi(token);
	token = strtok(NULL,delims);
	maxI = atoi(token);

	tilesReqd = malloc(numFemtocells *sizeof(int*));
	
	for (i=0; i<numFemtocells; i++)
	{
		tilesReqd[i] = malloc(sizeof(int)*numFrames);	
	}
	numInterferers = malloc(sizeof(int)*numFemtocells);	
	Interferers = malloc(numFemtocells *sizeof(int*));
	
	for (i=0; i<numFemtocells; i++)
	{
		Interferers[i] = malloc(numFemtocells *sizeof(int));
	}
	
	for (i=0; i<numFemtocells; i++)
	{
		numInterferers[i] = 0;
		for (ifr=0; ifr < numFemtocells; ifr++)
		{
			Interferers[i][ifr] = 0;
		}
	}

	fgets(linebuffer, 2000, file);
	printf("line %s",linebuffer);
	while (!feof(file))
	{
		token = strtok(linebuffer,delims);
		i = atoi(token);
		printf("\ni %d",i);
		token=strtok(NULL,delims);
		for ( f=0; f<numFrames; f++)
		{
			req = atoi(token);
			printf("req %d ",req);
			tilesReqd[i][f] = req;
			token=strtok(NULL,delims);
		}

		while (token!=NULL)
		{
			ifr = atoi(token);
			Interferers[i][ifr] = 1;
			numInterferers[i]++;
			token=strtok(NULL,delims);
		}
		fgets(linebuffer, 2000, file);
		printf("line %s",linebuffer);
	}

}
void printInput()
{
	int f, i;

	printf("number of Femtocells %d number of Tiles %d \n",numFemtocells, numTiles);

	for (f=0; f<numFemtocells; f++)
	{
		printf("\n Femtocell %d number of Interferers %d Interferers ",f, numInterferers[f]);
		for (i=0; i <numFemtocells; i++)
		{
			if (Interferers[f][i]==1)
			{
				printf("%d ",i);
			}
		}
	}

}
